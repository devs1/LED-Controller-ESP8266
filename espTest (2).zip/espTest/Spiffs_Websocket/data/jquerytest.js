$(document).ready(function(){

var rangeslider;
var slidebox;
var tabindex = 0;
var changeIndex = 0;	
	
	$('li').click('show.bs.tab',function(){		//Change all ID's and headings to channel index value
		changeIndex = ($(this).index());

		$('[id^="ch"]').attr('id', function(_, id){
			return id.replace(/\d+/, changeIndex);
		});										
		
		$('h3').html('Channel '+changeIndex);
	});

	rangeslider = $('input[type="range"]').on('input', function() {		//PWM slider 
		slidebox = $('input[type="text"][id*="pwm"]');
		slidebox[tabindex].value = this.value;
		
	});
	
	$('.clockpicker').clockpicker({		//Clockpicker
		placement: 'bottom',
		align: 'left',
		autoclose: true,
	});
	
	$(function(){		//Colour Picker		
		$('[id$="cp"]').colorpicker({
			useAlpha: false,
			container: true,
			format: 'hex',
			extensions: [
			{
				name: 'swatches',
				options: {
				colors: {
					"Royal Blue": '#0000cc',
					'Blue': '#33ccff',
					'Cool White': '#ffffff',
					'Warm White': '#ffffcc',
					'Red': '#ff0000',
					'Deep Red': '#cc0033',
					'Cyan': '#00ffff',
					'Green': '#41BA2C',
					'Lime': '#B8F971',
					'UV-A 380-400nm': '#9933ff',
				},
				namesAsValues: true
			  }
			}
		  ]
		});
	});
});	