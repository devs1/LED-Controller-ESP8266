var Socket;
var changedID;
	
	function init() {
		Socket = new WebSocket('ws://' + window.location.hostname + ':81/');
	}
	function sendNumberBrightness(){
		Socket.send('#'+document.getElementById('numberbrightness').value);
	}
	function sendSliderBrightness(){
		changedID = document.getElementsByClassName('custom-range');
		Socket.send('#'+(changedID[0].value));
	}	

	
