	$(document).ready(function(){
	var $rangesliderB = $('#sliderbrightness');
	var $numboxB = $('#numberbrightness');
	$rangesliderB.on('input', function(){
			$numboxB[0].value = this.value;
	});

	$numboxB.on('input', function(){
		$rangesliderB.val(this.value).change();
	});
	var $rangesliderCW = $('#CWsliderbrightness');
	var $numboxCW = $('#CWnumbrightness');
	$rangesliderCW.on('input', function(){
			$numboxCW[0].value = this.value;
	});

	$numboxCW.on('input', function(){
		$rangesliderCW.val(this.value).change();
	});
	
		$('.clockpicker').clockpicker({
			placement: 'bottom',
			align: 'left',
			autoclose: true,
		});	
	});

	