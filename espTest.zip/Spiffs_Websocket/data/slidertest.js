
	var Socket;
    function init() {
      Socket = new WebSocket('ws://' + window.location.hostname + ':81/');
    }
	function sendNumberBrightness(){
      Socket.send('#'+document.getElementById('numberbrightness').value);
    }
    function sendSliderBrightness(){
      Socket.send('#'+document.getElementById('sliderbrightness').value);
    }
	

	
